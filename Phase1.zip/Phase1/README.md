# COMP-518-Cloud-Services
Assignments for Cloud Services course (COMP-518) at TUC

Run with docker compose up -d --build

Stop local instance with 
    docker stop $(docker ps -a -q)

Bugs:
    changing product name (Disabled) does not update image file